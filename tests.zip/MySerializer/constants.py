PRIMITIVES = (bool, int, str, float, type(None))
COLLECTIONS = (list, tuple, set, dict)